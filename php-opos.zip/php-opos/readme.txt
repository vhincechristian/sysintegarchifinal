Images used (Credits to the owners):

- https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ7Pa6bhEUNGxoyaAj3BAnVlzA7QuRl_9uJ9g&usqp=CAU
-https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.sweetsteep.com%2Flemon-iced-tea-recipe%2F&psig=AOvVaw1_3J7n1swQnDC-ecrBsHk6&ust=1600738370840000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCLjR4omQ-esCFQAAAAAdAAAAABAD
 - https://diabetesstrong.com/wp-content/uploads/2015/08/Stuffed-Chicken-Breast-Recipe-500x500.jpg
 - https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.pinterest.at%2Fpin%2F569142471636844141%2F&psig=AOvVaw05HQhlrVyVM9nqXGNYVZas&ust=1600739179869000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCPj06rOQ-esCFQAAAAAdAAAAABAD
 -https://www.google.com/url?sa=i&url=https%3A%2F%2Fmsmarket.coop%2Fblog%2Fcelebrate-family-meals-month%2F&psig=AOvVaw3tQ9oaEGWrx1oVJnZKNsiK&ust=1600740680344000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCJDB3POV-esCFQAAAAAdAAAAABAD
 -https://www.google.com/url?sa=i&url=https%3A%2F%2Funsplash.com%2Fimages%2Ffood&psig=AOvVaw0ArxRDdKd-c1bv3rLdxMQ5&ust=1600741101989000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCOCggr2X-esCFQAAAAAdAAAAABAD
 -https://www.google.com/imgres?imgurl=https%3A%2F%2Fi.pinimg.com%2F736x%2Ffc%2F27%2F32%2Ffc2732287ffb7ca6a7b88db50dbcb180.jpg&imgrefurl=https%3A%2F%2Fwww.pinterest.com.au%2Fpin%2F791015122026175306%2F&tbnid=dqUrhAivuuvuZM&vet=12ahUKEwiBlKasnvnrAhVXAqYKHdZ-CHoQMygDegUIARCxAQ..i&docid=6ylTBnqhTMyPQM&w=646&h=468&q=meals%20fried%20free%20download&hl=en&ved=2ahUKEwiBlKasnvnrAhVXAqYKHdZ-CHoQMygDegUIARCxAQ
 -
